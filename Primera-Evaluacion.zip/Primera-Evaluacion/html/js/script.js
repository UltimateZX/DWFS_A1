document.getElementById("menu-toggle").addEventListener('click', function() {
    var nav = document.querySelector('.navbar-nav');
    nav.classList.toggle('show');
});